package com.application.latticeinnovations.view.ui

import android.os.Bundle
import android.os.Handler
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.application.latticeinnovations.R
import com.application.latticeinnovations.databinding.FragmentNewsMainBinding
import com.application.latticeinnovations.view.adaptor.NewsPageAdapter
import com.application.latticeinnovations.viewModel.NewsViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * Fragment class to load the result and do all the major operations where the user will be able to see
 */
@AndroidEntryPoint
class NewsMainFragment : Fragment() {

    lateinit var newsMainBinding: FragmentNewsMainBinding
    private val newsViewModel: NewsViewModel by viewModels()
    private val delay = 5000
    lateinit var newsPageAdapter: NewsPageAdapter
    private var runnable: Runnable? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        newsMainBinding =
            DataBindingUtil.inflate(inflater, R.layout.fragment_news_main, container, false)
        return newsMainBinding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        newsPageAdapter = NewsPageAdapter()
        setAdaptor()
        loadPageData()
        searchload()
    }

    /**
     * Method to load the page once the app is Launch
     */
    private fun loadPageData() {
        newsViewModel.getPageData().observe(this, {
            it?.let {
                CoroutineScope(Dispatchers.Main).launch {
                    newsPageAdapter.submitData(it)
                }
            }
        })
    }

    /**
     * Method to load the data once the user opt to search
     */
    private fun searchload() {
        newsMainBinding.etToSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {
            }

            override fun afterTextChanged(p0: Editable?) {
                if (p0 != null) {
                    val handler = Handler()
                    handler.postDelayed(Runnable {
                        kotlin.run {
                            loadSearchData(newsMainBinding.etToSearch.text.toString())
                        }
                    }, 5000)
                } else {
                    loadPageData()
                    val handler = Handler()
                    handler.postDelayed(Runnable {
                        loadPageData()
                        Toast.makeText(context, "Refreshed", Toast.LENGTH_SHORT).show()
                    }.also { runnable = it }, delay.toLong())
                }
            }
        })
    }

    /**
     * Method to load the data once the user finished giving a keyword to search
     */
    private fun loadSearchData(query: String) {
        newsViewModel.getPageSearchData(query).observe(viewLifecycleOwner, {
            it?.let {
                CoroutineScope(Dispatchers.Main).launch {
                    newsPageAdapter.submitData(it)
                }
            }
        })
    }

    /**
     * Setting adaptor class how the user can see
     */
    private fun setAdaptor() {
        newsPageAdapter = NewsPageAdapter()
        val linearLayoutManager = LinearLayoutManager(context)
        newsMainBinding.rvMainNews.apply {
            adapter = newsPageAdapter
            layoutManager = linearLayoutManager
        }
    }
}