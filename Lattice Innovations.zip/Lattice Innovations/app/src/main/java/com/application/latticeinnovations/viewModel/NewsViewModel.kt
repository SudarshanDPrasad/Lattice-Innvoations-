package com.application.latticeinnovations.viewModel

import androidx.lifecycle.ViewModel
import com.application.latticeinnovations.repository.NewsRepo
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

/**
 * View Model Class which acts a bridge between model and ui class
 */
@HiltViewModel
class NewsViewModel @Inject constructor(private val newsRepo: NewsRepo) : ViewModel() {

    fun getPageData() = newsRepo.getPageList()
    fun getPageSearchData(query: String) = newsRepo.getPageSearchList(query)
}