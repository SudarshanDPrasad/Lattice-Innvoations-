package com.application.latticeinnovations.model.remote

import retrofit2.http.GET
import retrofit2.http.Query


/**
 * Api Class to load the End Points
 */
interface ApiClient {

    /**
     * https://newsapi.org/v2/top-headlines?country=in&category=business&apiKey=ab424053c14248b6bbb7da59fa401cfd (for search category )
     * https://newsapi.org/v2/everything?q=apple&from=2022-02-14&to=2022-02-14&sortBy=popularity&apiKey=ab424053c14248b6bbb7da59fa401cfd (for all category )
     */

    @GET("v2/top-headlines?country=in&category=business&apiKey=ab424053c14248b6bbb7da59fa401cfd")
    suspend fun getData(
        @Query("page") Page: Int
    ): ResponseDTO

    @GET("v2/top-headlines")
    suspend fun getSearchData(
        @Query("country") country: String = "in",
        @Query("category") category: String,
        @Query("apiKey") apiKey: String = "ab424053c14248b6bbb7da59fa401cfd",
        @Query("page") Page: Int
    ): ResponseDTO
}